﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace doubleLL
{
    public class Node
    {
        public int data;
        public Node prev;
        public Node next;
    };
    public class doubleLL
    {
        public Node head;
        public int count;
        public doubleLL()
        {
            count = 0;
            head = null;
        }
        public Node createnode(int ele)
        {
            Node temp = new Node();
            temp.data = ele;
            temp.prev = null;
            temp.next = null;
            count++;
            return temp;
        }

        public void insertbegin(int ele)
        {
            Node new_node = createnode(ele);
            new_node.next = head;
            new_node.prev = null;
            if (head != null)
               head.prev = new_node;
            head = new_node;
            count++;
        }
        public void insertend(int ele)
        {
            Node new_node = createnode(ele);
            Node last = head;
            new_node.next = null;
            if (head == null)
            {
                new_node.prev = null;
                head = new_node;
                return;
            }
            while (last.next != null)
                last = last.next;
            last.next = new_node;
            new_node.prev = last;
            count++;
        }
        public void display()
        {
            if(head==null)
                Console.WriteLine("elements in the lists are NOT PRESENT: ");
            else
            {
                Console.WriteLine("elements are : ");
                Node temp;
                temp = head;
                while (temp != null)
                {
                    Console.WriteLine(temp.data +"\t");
                    temp = temp.next;
                }
            }
            Console.WriteLine();
        }
        public void insertpos(int ele, int pos)
        {
            if (pos == 1)
                insertbegin(ele);
            else if (pos == count + 1)
                insertend(ele);
            else
            {
                Node new_node = createnode(ele);
                Node pn, cn;
                pn = cn = head;
                for(int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.next;
                }
                pn.next = new_node;
                new_node.next = cn;
                count++;
            }

        }
        public void deletebegin()
        {
            if(head==null)
                Console.WriteLine("no element in list");
            else
            {
                Node temp = head;
                head = head.next;
                Console.WriteLine("deleting......"+temp.data);
                temp = null;
                count--;
            }
        }
        public void deleteend()
        {
            if (head == null)
                Console.WriteLine("no element in list");
            else
            {
                Node pn, cn;
                pn = cn = head;
                while (cn.next != null)
                {
                    pn = cn;
                    cn = cn.next;
                }
                if (pn == cn)
                    head = null;
                pn.next = null;
                Console.WriteLine("deleting..... " + cn.data);
                cn = null;
                count--;
            }
        }
        public void deletepos(int pos)
        {
            if (pos == 1)
                deletebegin();
            else if (pos == count)
                deleteend();
            else
            {
                Node pn, cn;
                pn = cn = head;
                for(int i = 1; i < pos; i++)
                {
                    pn = cn;
                    cn = cn.next;
                }
                pn.next = cn.next;
                Console.WriteLine("deleting......."+cn.data);
                cn = null;
                count--;
            }
        }
        public void find(int ele)
        {
            int i = 1;
            bool flag = false;
            if (head == null)
            {
                Console.WriteLine("list empty");
                return;
            }
            while (head != null)
            {
                if (head.data == ele)
                {
                    flag = true;
                    break;
                }
                head = head.next;
                i = i + 1;

            }
            if (flag)  
            Console.WriteLine("Node is present in the list at the position : " +i);  
            else
                Console.WriteLine("Node is not present in the list");
        }
        public void find(int ele, int oc)
        {
            int counter = 0;
            int i = 1;
            bool flag = false;
            if (head == null)
            {
                Console.WriteLine("list empty");
                return;
            }
            while (head != null)
            {
                if (head.data == ele)
                {
                    flag = true;
                    counter++;
                }
                head = head.next;
                i = i + 1;
                
            }
            if (flag)
            {
                if (counter == oc)
                {
                    Console.WriteLine("occurance exists at position......"+i);
                }
                else
                    Console.WriteLine("occurence does not exists");
            }
            else
                Console.WriteLine("search key not found");
            
            


        }
    }
}
